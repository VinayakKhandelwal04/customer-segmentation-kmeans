# Demand Forecasting

## Description
Time series forecasting using Holt-Winters method.

## Tech Used
- Python, Pandas, Statsmodels

## How to Run
Run `demand_forecasting.ipynb` after ensuring `sales.csv` is in the same directory.