# Movie Recommendation System

## Description
Streamlit-based app to recommend movies using genre similarity.

## Tech Used
- Python, Streamlit, Scikit-learn

## How to Run
1. Ensure `data.csv` is in the folder
2. Run `streamlit run app.py`