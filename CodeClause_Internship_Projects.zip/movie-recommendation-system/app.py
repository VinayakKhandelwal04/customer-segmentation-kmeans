import streamlit as st
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer

st.title("Movie Recommendation System")

df = pd.read_csv("data.csv")
cv = CountVectorizer()
vector = cv.fit_transform(df['genres'])
similarity = cosine_similarity(vector)

movie = st.selectbox("Select a movie:", df['title'].values)

if st.button("Recommend"):
    idx = df[df['title'] == movie].index[0]
    scores = list(enumerate(similarity[idx]))
    sorted_scores = sorted(scores, key=lambda x: x[1], reverse=True)[1:6]
    st.subheader("Recommended Movies:")
    for i in sorted_scores:
        st.write(df.iloc[i[0]]['title'])