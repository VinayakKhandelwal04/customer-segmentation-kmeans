# Crop Disease Detection

## Description
Flask-based web app using deep learning to detect crop diseases from images.

## Tech Used
- Python, Flask, TensorFlow

## How to Run
1. Place a dummy model as `model.h5`
2. Run `app.py`
3. Open browser and visit `http://127.0.0.1:5000`