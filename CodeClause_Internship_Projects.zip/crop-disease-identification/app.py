from flask import Flask, render_template, request
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import os

app = Flask(__name__)
model = load_model('model.h5')

@app.route('/', methods=['GET', 'POST'])
def index():
    result = ""
    if request.method == 'POST':
        img = request.files['image']
        path = os.path.join('static', img.filename)
        img.save(path)
        img_tensor = image.load_img(path, target_size=(224, 224))
        img_tensor = image.img_to_array(img_tensor) / 255.
        img_tensor = np.expand_dims(img_tensor, axis=0)
        pred = model.predict(img_tensor)
        result = "Healthy" if pred[0][0] < 0.5 else "Diseased"
    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)