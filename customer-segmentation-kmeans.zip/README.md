# Customer Segmentation using K-Means

## Description
Clusters customers based on spending score and income using K-Means.

## Tech Used
- Python, Pandas, Matplotlib, Scikit-learn

## How to Run
Run `customer_segmentation.ipynb` after ensuring `customers.csv` is in the same directory.